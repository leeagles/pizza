﻿using System;
using System.Windows.Forms;
using pizza;
using PizzaApp.models;

namespace PizzaApp
{
    public partial class selectbase : Form
    {
        private PizzaMod pizza;

        public selectbase(PizzaMod pizzaVariable)
        {
            InitializeComponent();

            this.pizza = pizzaVariable;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pizza.Crust.Add("Napoletana");
                checkBox5.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked)
            {
                pizza.Crust.Add("Greek");
                checkBox1.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked)
            {
                pizza.Crust.Add("St.Louise");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox5.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }
        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                pizza.Crust.Add("Chicago");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }
        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                pizza.Crust.Add("Focaccia");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                pizza.Crust.Add("Pizza Bianca");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox2.Checked = false;
                checkBox10.Checked = false;
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
           if (checkBox10.Checked)
            {
                pizza.Crust.Add("New York Style");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox2.Checked = false;
                checkBox5.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                pizza.Crust.Add("Pizza Siciliana");
                checkBox1.Checked = false;
                checkBox8.Checked = false;
                checkBox7.Checked = false;
                checkBox4.Checked = false;
                checkBox3.Checked = false;
                checkBox5.Checked = false;
            }
        }

        private void selectbase_Load(object sender, EventArgs e)
        {

        }

        private void continueButton1_Click(object sender, EventArgs e)
        {
            this.Hide();

            btcselectsize btcselectsize = new btcselectsize(pizza);
            this.Hide();
            btcselectsize.Show();
        }

        private void gobackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProPizza ProPizza= new ProPizza();
            this.Hide();
            ProPizza.Show();
        }
    }
}
