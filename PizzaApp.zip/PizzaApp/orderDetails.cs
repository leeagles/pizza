﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaApp.models;
using PizzaApp;

namespace pizza
{
    public partial class orderDetails : Form
    {
        public PizzaMod pizza;
        int CurrentTotal;
        string currentOrderString;
        ////////public PizzaMod pizzavariable;
        public orderDetails(PizzaMod pizzavariable)
        {
            InitializeComponent();
            pizza = pizzavariable;
            PizzaOrder.pizzalist.Add(pizza);
            CalculatePizzaCost();
            buildVisualPizzaOrder();
        }

        private void BasketForm_Load(object sender, EventArgs e)
        {
            this.currentOrder.Text = currentOrderString;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void OrderDetails_Load(object sender, EventArgs e)
        {

        }
        private void CurrentOrder_Click(object sender, EventArgs e)
        {

        }

        private void gobackButton_Click(object sender, EventArgs e)
        {
            
        }

        private void currentOrder_Click_1(object sender, EventArgs e)
        {

        }

        private void checkoutButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Current Price: " + CurrentTotal.ToString());
            MessageBox.Show("Thank you for using our application");

        }

        private void CalculatePizzaCost()
        {
            CurrentTotal = 0;
            foreach (PizzaMod pizza in PizzaOrder.pizzalist)
            {
                CurrentTotal += pizza.Price;
            }
        }

        private void buildVisualPizzaOrder()
        {
            StringBuilder sb = new StringBuilder();

            foreach (PizzaMod pizza in PizzaOrder.pizzalist)
            {
                sb.Append(pizza.Name + ": £");
                sb.Append(pizza.Price.ToString());
                sb.Append(Environment.NewLine);
                foreach (string topping in pizza.Toppings)
                {
                    sb.Append(topping);
                    sb.Append(Environment.NewLine);
                }
                sb.AppendLine("-----------------");
                sb.Append(Environment.NewLine);
            }
            currentOrderString = sb.ToString();
        }

        private void AddAnotherPizzaButton_Click(object sender, EventArgs e)
        {
            ProPizza selectPizzaForm = new ProPizza();
            this.Hide();
            selectPizzaForm.Show();
        }
    }
}
