﻿namespace pizza
{
    partial class orderDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orderDetails));
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.checkoutButton = new System.Windows.Forms.Button();
            this.AddAnotherPizzaButton = new System.Windows.Forms.Button();
            this.currentOrder = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Garamond", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(476, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(263, 82);
            this.label3.TabIndex = 40;
            this.label3.Text = "Order details:";
            this.label3.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(1, 1);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(349, 331);
            this.pictureBox4.TabIndex = 36;
            this.pictureBox4.TabStop = false;
            // 
            // checkoutButton
            // 
            this.checkoutButton.Location = new System.Drawing.Point(483, 273);
            this.checkoutButton.Name = "checkoutButton";
            this.checkoutButton.Size = new System.Drawing.Size(207, 77);
            this.checkoutButton.TabIndex = 45;
            this.checkoutButton.Text = "CheckOut Pizza(s)";
            this.checkoutButton.UseVisualStyleBackColor = true;
            this.checkoutButton.Click += new System.EventHandler(this.checkoutButton_Click);
            // 
            // AddAnotherPizzaButton
            // 
            this.AddAnotherPizzaButton.Location = new System.Drawing.Point(714, 273);
            this.AddAnotherPizzaButton.Name = "AddAnotherPizzaButton";
            this.AddAnotherPizzaButton.Size = new System.Drawing.Size(207, 77);
            this.AddAnotherPizzaButton.TabIndex = 44;
            this.AddAnotherPizzaButton.Text = "Add Another Pizza";
            this.AddAnotherPizzaButton.UseVisualStyleBackColor = true;
            this.AddAnotherPizzaButton.Click += new System.EventHandler(this.AddAnotherPizzaButton_Click);
            // 
            // currentOrder
            // 
            this.currentOrder.AutoSize = true;
            this.currentOrder.Location = new System.Drawing.Point(480, 100);
            this.currentOrder.Name = "currentOrder";
            this.currentOrder.Size = new System.Drawing.Size(67, 13);
            this.currentOrder.TabIndex = 43;
            this.currentOrder.Text = "current order";
            this.currentOrder.Click += new System.EventHandler(this.currentOrder_Click_1);
            // 
            // orderDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 358);
            this.Controls.Add(this.checkoutButton);
            this.Controls.Add(this.AddAnotherPizzaButton);
            this.Controls.Add(this.currentOrder);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox4);
            this.Name = "orderDetails";
            this.Text = "Order Details";
            this.Load += new System.EventHandler(this.OrderDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button checkoutButton;
        private System.Windows.Forms.Button AddAnotherPizzaButton;
        private System.Windows.Forms.Label currentOrder;
    }
}