﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaApp.models;

namespace PizzaApp
{
    public partial class ProPizza : Form
    {
        public PizzaMod pizza;
        
        public ProPizza()
        {
            PizzaMod pizza = new PizzaMod();
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BeTheCreator_Click(object sender, EventArgs e)
        {
            this.Hide();
            selectbase selectpizzaBase = new selectbase(pizza);
            this.Hide();
            selectpizzaBase.Show();
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
}
