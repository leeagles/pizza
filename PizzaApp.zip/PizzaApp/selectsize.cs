﻿using System;
using System.Windows.Forms;
using pizza;
using PizzaApp.models;

namespace PizzaApp
{
    public partial class selectsize : Form
    {
        private PizzaMod pizza;

        public PizzaMod Pizza;

        public selectsize(PizzaMod pizzaVariable)
        {
            InitializeComponent();
            this.Pizza = pizzaVariable;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void selectsize_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Pizza.Toppings.Add("Small");
                checkBox2.Checked = false;
                checkBox3.Checked = false;
            }
        }

        private void continueButton1_Click(object sender, EventArgs e)
        {
            this.Hide();

            orderDetails orderDetails = new orderDetails(Pizza);
            this.Hide();
            orderDetails.Show();
        }

        private void gobackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu Menu = new Menu();
            this.Hide();
            Menu.Show();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Pizza.Toppings.Add("Medium");
            checkBox1.Checked = false;
            checkBox3.Checked = false;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Pizza.Toppings.Add("Large");
            checkBox2.Checked = false;
            checkBox1.Checked = false;
        }
    }
}
