﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaApp.models
{
    public class PizzaMod
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public List<string> Toppings { get; set; }
        public List<string> Crust { get; set; }
        public PizzaMod()
        {
            Toppings = new List<string>();
            Crust = new List<string>();
        }
    }
}
