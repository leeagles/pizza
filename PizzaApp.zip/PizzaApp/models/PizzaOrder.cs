﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaApp.models
{
    public static class PizzaOrder
    {
        public static List<PizzaMod> pizzalist;
        static PizzaOrder()
        {
            pizzalist = new List<PizzaMod>();
        }

    }
}
