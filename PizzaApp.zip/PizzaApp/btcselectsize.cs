﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PizzaApp.models;
using pizza;

namespace PizzaApp
{
    public partial class btcselectsize : Form
    {
        private PizzaMod Pizza;
        public btcselectsize(PizzaMod pizzaVariable)
        {
            InitializeComponent();
            this.Pizza = pizzaVariable;
        }

        private void continueButton1_Click(object sender, EventArgs e)
        {

        }

        private void gobackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            selectbase selectbase = new selectbase(Pizza);
            this.Hide();
            selectbase.Show();
        }
    }
}
