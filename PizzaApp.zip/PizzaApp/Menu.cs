﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaApp.models;

namespace PizzaApp
{
    public partial class Menu : Form
    {

        public delegate void OnHideEvent(object sender, EventArgs e);
        public PizzaMod pizza;
        public Menu()
        {
            InitializeComponent();
            pizza = new PizzaMod();

        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            selectsize selectsize = new selectsize(pizza);
            this.Hide();
            selectsize.Show();
        }

        private void gobackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProPizza ProPizza = new ProPizza();
            this.Hide();
            ProPizza.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Focaccia";
            pizza.Price = 8;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Margherita";
            pizza.Price = 9;

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Marinara";
            pizza.Price = 11;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Diavola";
            pizza.Price = 13;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Boscaiola";
            pizza.Price = 13;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Quattro formaggi";
            pizza.Price = 13;
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Capricciosa";
            pizza.Price = 11;
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Funghi";
            pizza.Price = 15;
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Salsiccia";
            pizza.Price = 15;
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            pizza.Name = "Salsiccia e patatine";
            pizza.Price = 17;
        }
    }
}
